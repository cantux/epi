# how to run
1- Create 5x5 game with 5 bombs
```
python sweeper.py
```

2- Create a 10x10 game with 10 bombs

```
python sweeper.py 10 10 10
```


